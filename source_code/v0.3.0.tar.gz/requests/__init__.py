# -*- coding: utf-8 -*-

import packages
from core import *

from core import __version__
